fsharpc -a Sexp.fs
fsharpc RunLISP.fsx -o lisp.exe -r Sexp.dll
